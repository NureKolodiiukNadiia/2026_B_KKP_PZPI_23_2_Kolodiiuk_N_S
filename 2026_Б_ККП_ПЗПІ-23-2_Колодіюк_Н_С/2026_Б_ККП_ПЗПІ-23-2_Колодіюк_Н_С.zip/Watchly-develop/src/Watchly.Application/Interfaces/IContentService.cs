using Watchly.Application.Models.Content;
using Watchly.Domain.Entities;
using Watchly.Domain.Utils;

namespace Watchly.Application.Interfaces;

public interface IContentService
{
    Task<Result<IEnumerable<Keyword>>> GetNextKeywordSuggestionAsync(string searchTerm, CancellationToken ct = default);

    Task<Result<IEnumerable<SpokenLanguage>>> GetSpokenLanguagesAsync(CancellationToken ct = default);

    Task<Result<TitleInfo>> GetTitleByIdAsync(int titleId, CancellationToken ct);

    Task<Result<EpisodeInfo>> GetEpisodeByIdAsync(int episodeId, CancellationToken ct);

    Task<Result<IEnumerable<TitleShortInfo>>> SearchTitlesAsync(
        string searchTerm, int pageSize, int page, IEnumerable<int> titleTypes, CancellationToken ct);
    
    Task<Result<IEnumerable<TitleShortInfo>>> FilterTitlesAsync(
        FilterRequest filterOptions, CancellationToken ct);
}
